<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from techydevs.com/demos/themes/html/aduca-demo/aduca/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Jun 2022 06:17:33 GMT -->
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="TechyDevs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Shah Satnam ji Girls School Sirsa | Support Staff</title>

    <!-- Google fonts -->
    <?php include('inc_include.php');?>
    <!-- end inject -->
</head>
<body>
<?php 
$menu ="support-staff.php";
include('header.php');?>
<!-- ================================
    START BREADCRUMB AREA
================================= -->
<section class="breadcrumb-area section-padding img-bg-2">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-content d-flex flex-wrap align-items-center justify-content-between">
                    <div class="section-heading">
                        <h2 class="section__title text-white">Support Staff</h2>
                    </div>
                    <ul class="generic-list-item generic-list-item-white generic-list-item-arrow d-flex flex-wrap align-items-center">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="faculty.php">Faculty</a></li>
                        <li>Support Staff</li>
                    </ul>
                </div><!-- end breadcrumb-content -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
    </div><!-- end container -->
</section><!-- end breadcrumb-area -->
<!-- ================================
    END BREADCRUMB AREA
================================= -->
<section>
    <div class="container">
    <div class="section-heading text-center">
                <h2 class="section__title">
Support Staff</h2>
                <span class="section-divider"></span>
            </div>
        <div class="row">
            
            
          
            <div class="col-lg-12">
                <br>
               <img src="images/facility/support-staf.jpg" width="100%">
            </div>
            <div class="col-lg-12 mt-5">
            
            <p class="common-text"><b>Centre: Dr. Sheela Puniya</b>
                <br>
               <b> Left to Right:</b> Ms. Mamta (B.A), Ms. Sharwana Kumari (M.A (Pol. Sci.), Ms. Pinki Putela (M.Com, B.Ed), Ms. Arshwinder (B.A, B.Ed), Ms. Sumitra Devi (B.A, B.Ed, Diploma in Computer), Ms. Krishna (B.A, B.Lib)
                <br>
                <b>Sitting Left to Right:</b> Ms. Jyoti (Diploma in Hardware & Networking), Ms Sonia, Ms. Amarjeet Kaur (B.A, PGDCA, M.Sc), Ms. Deepika (MBA, ADCA
            </p>
        </div>
        </div>
    </div>
</section>

<?php include('inc_footer.php');?>

<!-- start scroll top -->
<div id="scroll-top">
    <i class="la la-arrow-up" title="Go top"></i>
</div>
<!-- end scroll top -->

<!-- template js files -->
<?php include('footer.php');?>
</body>

<!-- Mirrored from techydevs.com/demos/themes/html/aduca-demo/aduca/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Jun 2022 06:17:33 GMT -->
</html>