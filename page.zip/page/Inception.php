<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from techydevs.com/demos/themes/html/aduca-demo/aduca/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Jun 2022 06:17:33 GMT -->
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="TechyDevs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title> Shah Satnam ji Girls School Sirsa| Inception</title>

    <!-- Google fonts -->
    <?php include('inc_include.php');?>
    <!-- end inject -->
</head>
<body>
<?php 
$menu ="inception.php";
include('header.php');?>
<!-- ================================
    START BREADCRUMB AREA
================================= -->
<section class="breadcrumb-area section-padding img-bg-2">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-content d-flex flex-wrap align-items-center justify-content-between">
                    <div class="section-heading">
                        <h2 class="section__title text-white">Inception</h2>
                    </div>
                    <ul class="generic-list-item generic-list-item-white generic-list-item-arrow d-flex flex-wrap align-items-center">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                        <li>Inception</li>
                    </ul>
                </div><!-- end breadcrumb-content -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
    </div><!-- end container -->
</section><!-- end breadcrumb-area -->
<!-- ================================
    END BREADCRUMB AREA
================================= -->
<section class  ="mt-5">
    <div class="container">
     <div class="section-heading text-center">
            <h2 class="section__title">Inception</h2>
            <span class="section-divider"></span>
          </div>
        <div class="row">
          
          <div class="col-lg-6 mt-5"> 
            <img src="images/about/Inception/1.png" width="100%">
        </div>
            <div class="col-lg-6"><p class="common-text">
There was a time when education means nurturing of a child like a plant to grow as a sturdy tree beneficial for the whole society. The commercialization of education has changed the meaning of education in society. There is a great loss of moral values. Education makes the child only a money making machine without caring for his fellow beings. In order to raise the standard of women education which is being neglected in our society since ancient period, Present Maven mentor of Dera Sacha Sauda, Sirsa Saint Dr. Gurmeet Ram Rahim Singh Ji Insan decided to unfurl the flag of education with spirituality in the midst of self-centered and materialistic age and blessed the society with a boon in 1994 by establishing Shah Satnam Ji Girls’ School in the lush green environment of Sirsa away from the humdrum of city life. The founder father St. Dr. MSG inaugurated the institute by joining two ends of the ribbon on 1st April, 1994. 
<br>
A registered society named Shah Satnam Ji Educational Institutes; Sirsa was established with Registration No. 1164 to run the educational Institutes. It comprises 09 members of the society including Chairman, Vice Chairman, Secretary and cashier. The School is recognized by CBSE New Delhi and is Provisionally Affiliated with Affiliation No. 530158 since 1996. This is being updated after every five years and latest up to 2024.
<br>
Since its inception, the institute is moving ahead in every field by the grace of Almighty. The optimal learning environment is being provided to every child for the all-inclusive growth. The students are not lagging behind in any field whether academics or cultural as the institute does not provide only formal education; it inculcates morality, integrity too and character-building is the foremost. 

</p> </div>
           
       </div>
    </div>
</section>



<?php include('inc_footer.php');?>

<!-- start scroll top -->
<div id="scroll-top">
    <i class="la la-arrow-up" title="Go top"></i>
</div>
<!-- end scroll top -->

<!-- template js files -->
<?php include('footer.php');?>
</body>

<!-- Mirrored from techydevs.com/demos/themes/html/aduca-demo/aduca/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Jun 2022 06:17:33 GMT -->
</html>