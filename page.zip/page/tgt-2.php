<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from techydevs.com/demos/themes/html/aduca-demo/aduca/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Jun 2022 06:17:33 GMT -->
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="TechyDevs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>
Shah Satnam ji Girls School Sirsa | TGT Staff</title>

    <!-- Google fonts -->
    <?php include('inc_include.php');?>
    <!-- end inject -->
</head>
<body>
<?php 
$menu ="tgt-2.php";
include('header.php');?>
<!-- ================================
    START BREADCRUMB AREA
================================= -->
<section class="breadcrumb-area section-padding img-bg-2">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-content d-flex flex-wrap align-items-center justify-content-between">
                    <div class="section-heading">
                        <h2 class="section__title text-white">TGT STAFF</h2>
                    </div>
                    <ul class="generic-list-item generic-list-item-white generic-list-item-arrow d-flex flex-wrap align-items-center">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="faculty.php">Faculty</a></li>
                        <li>TGT STAFF</li>
                    </ul>
                </div><!-- end breadcrumb-content -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
    </div><!-- end container -->
</section><!-- end breadcrumb-area -->
<!-- ================================
    END BREADCRUMB AREA
================================= -->
<section>
    <div class="container">
    <div class="section-heading text-center">
                <h2 class="section__title">TGT STAFF</h2>
                <span class="section-divider"></span>
            </div>
        <div class="row">
        

<div class="col-lg-12">
    <img src="images/facility/tgt-2.jpg" width="100%">
</div>
<div class="col-lg-12 mt-5">

            <p class="common-text"><b>Centre:</b> Dr. Sheela Puniya (Principal)
                <br>
                <b>
Left to Right:</b>  Ms. Nancy Chawla (B.Sc, M.Sc. (Math), Ms. Monika Chugh (B.Sc, B.Ed, MEE, HTET), Ms. Sarita Arora (M.A (History), B.Ed, Ms. Manju Bajaj (M.Sc (Maths), M.A (Hindi), PGDCA, B.Ed), Ms. Meenakshi Khurana (M.A (Hindi, B.Ed), Ms. Gunjan (B.A Hons (Eng), M.A (Eng), B.Ed),  Ms. Pooja Setia (M.A (Pbi.), M.Sc. (IT), Ms. Komal Preet (M.A (Eco, Edu, Punjabi), Ms. Nirmala Rani (M.A (Pbi), B.Ed, Gyani, Diploma in Electronics), Ms. Neeru Khattar (M.Sc (Maths), M.A (Eng), B.Ed, HTET), Ms. Kavita Arora (M.A, M.Phil (Eco), B.Ed), Ms. Urmil Sharma (M.A (Hindi, Pol. Sci.), HTET), Ms. Renu (M.A(Pol. Sci.), B.Ed, CTET)
</p>
</div>
</div>

        </div>
    </div>
</section>

<?php include('inc_footer.php');?>

<!-- start scroll top -->
<div id="scroll-top">
    <i class="la la-arrow-up" title="Go top"></i>
</div>
<!-- end scroll top -->

<!-- template js files -->
<?php include('footer.php');?>
</body>

<!-- Mirrored from techydevs.com/demos/themes/html/aduca-demo/aduca/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Jun 2022 06:17:33 GMT -->
</html>