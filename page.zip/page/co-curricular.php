<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from techydevs.com/demos/themes/html/aduca-demo/aduca/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Jun 2022 06:17:33 GMT -->
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="TechyDevs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>
Shah Satnam ji Girls School Sirsa | Academic</title>

    <!-- Google fonts -->
    <?php include('inc_include.php');?>
    <!-- end inject -->
</head>
<body>
<?php 
$menu ="Academic.php";
include('header.php');?>
<!-- ================================
    START BREADCRUMB AREA
================================= -->
<section class="breadcrumb-area section-padding img-bg-2">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-content d-flex flex-wrap align-items-center justify-content-between">
                    <div class="section-heading">
                        <h2 class="section__title text-white">Co-Curricular </h2>
                    </div>
                    <ul class="generic-list-item generic-list-item-white generic-list-item-arrow d-flex flex-wrap align-items-center">
                        <li><a href="index.php">Home</a></li>
                       
                        <li>Co-Curricular </li>
                    </ul>
                </div><!-- end breadcrumb-content -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
    </div><!-- end container -->
</section><!-- end breadcrumb-area -->
<!-- ================================
    END BREADCRUMB AREA
================================= -->
<!--======================================
        START GET STARTED AREA
======================================-->
<section>
    <div class="container mt-5 mb-5">
    <div class="section-heading text-center">
            <h2 class="section__title">Co-Curricular </h2>
            <span class="section-divider"></span>
          </div>   
    <div class="row">
        
            <div class=" co-mahend widthcustom mt-5 mb-5">
                <figure class="imag-effec">
                    <img src="images/home/26.png" class="img-responsive" alt="" style="width:270px!important;     height: 180px!important;"> 
                </figure> 
                <span class="headings">Full acivity calander </span> 
                <a class="more-newd" href="activity-plan.php">More Info</a>
            </div>
            <div class=" co-mahend widthcustom mt-5 mb-5">
                <figure class="imag-effec">
                    <img src="images/home/27.png" class="img-responsive" alt="" width="100%"> 
                </figure> 
                <span class="headings">Cultural Activities for Kinder Garden </span> 
                <a class="more-newd" href="kinder-garden.php">More Info</a>
            </div>
            <div class=" co-mahend widthcustom mt-5 mb-5">
                <figure class="imag-effec">
                    <img src="images/home/28.png" class="img-responsive" alt="" width="100%"> 
                </figure> 
                <span class="headings">Primary School Activity  </span> 
                <a class="more-newd" href="primary-school-activity.php">More Info</a>
            </div>
            <div class=" co-mahend widthcustom mt-5 mb-5">
                <figure class="imag-effec">
                    <img src="images/home/29.png" class="img-responsive" alt="" width="100%"> 
                </figure> 
                <span class="headings">Secondary School Activity </span> 
                <a class="more-newd" href="seccondary_school.php">More Info</a>
            </div>
            <div class=" co-mahend widthcustom mt-5 mb-5">
                <figure class="imag-effec">
                    <img src="images/home/30.png" class="img-responsive" alt="" width="100%"> 
                </figure> 
                <span class="headings">Tours & Excursions</span> 
                <a class="more-newd" href="tours.php">Results</a>
            </div>
            <div class=" co-mahend widthcustom mt-5 mb-5">
                <figure class="imag-effec">
                    <img src="images/home/31.png" class="img-responsive" alt="" width="100%"> 
                </figure> 
                <span class="headings">Scouts & Guide</span> 
                <a class="more-newd" href="scouts-&-guides.php">More Info</a>
            </div>
          
           
           
        </div>
    </div>
</section>
<!-- ================================
       START GET STARTED AREA
================================= -->
<?php include('inc_footer.php');?>

<!-- start scroll top -->
<div id="scroll-top">
    <i class="la la-arrow-up" title="Go top"></i>
</div>
<!-- end scroll top -->

<!-- template js files -->
<?php include('footer.php');?>
</body>

<!-- Mirrored from techydevs.com/demos/themes/html/aduca-demo/aduca/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Jun 2022 06:17:33 GMT -->
</html>