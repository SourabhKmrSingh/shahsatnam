<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from techydevs.com/demos/themes/html/aduca-demo/aduca/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Jun 2022 06:17:33 GMT -->
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="TechyDevs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>MOTIVATOR AND ROLE MODEL</title>

    <!-- Google fonts -->
    <?php include('inc_include.php');?>
    <!-- end inject -->
</head>
<body>
<!-- ================================
    START BREADCRUMB AREA
================================= -->
<?php
$menu ="motivation.php";

include('header.php');?>

<section class="breadcrumb-area section-padding img-bg-2">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-content d-flex flex-wrap align-items-center justify-content-between">
                    <div class="section-heading">
                        <h2 class="section__title text-white"> Motivator and role model</h2>
                    </div>
                    <ul class="generic-list-item generic-list-item-white generic-list-item-arrow d-flex flex-wrap align-items-center">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                        <li>Motivator and role model</li>
                    </ul>
                </div><!-- end breadcrumb-content -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
    </div><!-- end container -->
</section><!-- end breadcrumb-area -->
<!-- ================================
    END BREADCRUMB AREA
================================= -->

<!-- ==================================
START ABOUT AREA
================================= -->
<section class="mt-5">
    <div class="container">
        <div class="row">
           <h1>MOTIVATOR AND ROLE MODEL</h1>
           <br>
            <p class="color-bck">
            The personal values and beliefs of the Principal shape the ethos and frame the climate and culture of the school. Aligning the vision, beliefs and values both at the institutional and personal level is a dynamic and intricate process that needs extraordinary efforts and potentials. Being the pedagogical leader, Dr. Sheela Puniya possesses a developed vision for the school, converts it into mission and directs it as a desired goal that sets a direction for the school improvement and student learning. 
            <br>
            Various types of social and zestful activities are being administered for the students to execute her vision for the improvement of school and for imbibing unique qualities of excellence. Along with academic growth several activities like indoor and outdoor for personality development of the students are being held at regular intervals. 
All the academic and non-academic on-going operations in the school premises help in strengthening and enhancing the undertaken vision i.e. to be globally recognized as a distinguished center of academic excellence. 

            </p>
        </div>
    </div>
</section>

<!-- ==================================
END ABOUT AREA
================================= -->
<?php include('inc_footer.php');?>

<!-- start scroll top -->
<div id="scroll-top">
    <i class="la la-arrow-up" title="Go top"></i>
</div>
<!-- end scroll top -->

<!-- template js files -->
<?php include('footer.php');?>
</body>

<!-- Mirrored from techydevs.com/demos/themes/html/aduca-demo/aduca/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Jun 2022 06:17:33 GMT -->
</html>