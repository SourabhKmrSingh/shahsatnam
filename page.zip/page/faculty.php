<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from techydevs.com/demos/themes/html/aduca-demo/aduca/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Jun 2022 06:17:33 GMT -->
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="TechyDevs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>
Shah Satnam ji Girls School Sirsa | Facility</title>

    <!-- Google fonts -->
    <?php include('inc_include.php');?>
    <!-- end inject -->
</head>
<body>
<?php 
$menu ="facility.php";
include('header.php');?>
<!-- ================================
    START BREADCRUMB AREA
================================= -->
<section class="breadcrumb-area section-padding img-bg-2">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-content d-flex flex-wrap align-items-center justify-content-between">
                    <div class="section-heading">
                        <h2 class="section__title text-white">Faculty</h2>
                    </div>
                    <ul class="generic-list-item generic-list-item-white generic-list-item-arrow d-flex flex-wrap align-items-center">
                        <li><a href="index.php">Home</a></li>
                       
                        <li>Faculty</li>
                    </ul>
                </div><!-- end breadcrumb-content -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
    </div><!-- end container -->
</section><!-- end breadcrumb-area -->
<!-- ================================
    END BREADCRUMB AREA
================================= -->
<!--======================================
        START GET STARTED AREA
======================================-->
<section>
    <div class="container mt-5 mb-5">
    <div class="section-heading text-center">
            <h2 class="section__title">Faculty</h2>
            <span class="section-divider"></span>
          </div>   
    <div class="row">
        
            <div class=" co-mahend widthcustom mt-5 mb-5">
                <figure class="imag-effec">
                    <img src="images/home/14.png" class="img-responsive" alt="" style="width:270px!important;     height: 180px!important;"> 
                </figure> 
                <span class="headings">PGT 1</span> 
                <a class="more-newd" href="pgt-1.php">More Info</a>
            </div>
            <div class=" co-mahend widthcustom mt-5 mb-5">
                <figure class="imag-effec">
                    <img src="images/home/15.png" class="img-responsive" alt="" width="100%"> 
                </figure> 
                <span class="headings">PGT 2</span> 
                <a class="more-newd" href="pgt-2.php">More Info</a>
            </div>
            <div class=" co-mahend widthcustom mt-5 mb-5">
                <figure class="imag-effec">
                    <img src="images/home/16.png" class="img-responsive" alt="" width="100%"> 
                </figure> 
                <span class="headings">TGT 1</span> 
                <a class="more-newd" href="tgt-1.php">More Info</a>
            </div>
            <div class=" co-mahend widthcustom mt-5 mb-5">
                <figure class="imag-effec">
                    <img src="images/home/17.png" class="img-responsive" alt="" width="100%"> 
                </figure> 
                <span class="headings">TGT 2</span> 
                <a class="more-newd" href="tgt-2.php">More Info</a>
            </div>
            <div class=" co-mahend widthcustom mt-5 mb-5">
                <figure class="imag-effec">
                    <img src="images/home/18.png" class="img-responsive" alt="" width="100%"> 
                </figure> 
                <span class="headings">PRT</span> 
                <a class="more-newd" href="prt.php">More Info</a>
            </div>
            <div class=" co-mahend widthcustom mt-5 mb-5">
                <figure class="imag-effec">
                    <img src="images/home/19.png" class="img-responsive" alt="" width="100%"> 
                </figure> 
                <span class="headings">Support Staff</span> 
                <a class="more-newd" href="supports-staff.php">More Info</a>
            </div>
          
           
           
        </div>
    </div>
</section>
<!-- ================================
       START GET STARTED AREA
================================= -->
<?php include('inc_footer.php');?>

<!-- start scroll top -->
<div id="scroll-top">
    <i class="la la-arrow-up" title="Go top"></i>
</div>
<!-- end scroll top -->

<!-- template js files -->
<?php include('footer.php');?>
</body>

<!-- Mirrored from techydevs.com/demos/themes/html/aduca-demo/aduca/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Jun 2022 06:17:33 GMT -->
</html>