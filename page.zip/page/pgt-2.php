<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from techydevs.com/demos/themes/html/aduca-demo/aduca/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Jun 2022 06:17:33 GMT -->
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="TechyDevs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title> 
Shah Satnam ji Girls School Sirsa | PGT STAFF </title>

    <!-- Google fonts -->
    <?php include('inc_include.php');?>
    <!-- end inject -->
</head>
<body>
<?php 
$menu ="pgt-2.php";
include('header.php');?>
<!-- ================================
    START BREADCRUMB AREA
================================= -->
<section class="breadcrumb-area section-padding img-bg-2">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-content d-flex flex-wrap align-items-center justify-content-between">
                    <div class="section-heading">
                        <h2 class="section__title text-white">PGT STAFF</h2>
                    </div>
                    <ul class="generic-list-item generic-list-item-white generic-list-item-arrow d-flex flex-wrap align-items-center">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="faculty.php">Faculty</a></li>
                        <li>PGT STAFF</li>
                    </ul>
                </div><!-- end breadcrumb-content -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
    </div><!-- end container -->
</section><!-- end breadcrumb-area -->
<!-- ================================
    END BREADCRUMB AREA
================================= -->
<section>
    <div class="container">
    <div class="section-heading text-center">
            <h2 class="section__title">PGT STAFF</h2>
            <span class="section-divider"></span>
          </div>
        <div class="row">
        <div class="col-lg-12">
            <br>
            <img src="images/facility/pgt-2.jpg" width="100%">
           </div>

            <div class="col-lg-12 mt-5">
            
            <p class="common-text"><b>Centre:</b> Dr. Sheela Puniya (Principal)
            <br>
            <b>Left to Right:</b> Dr. Kavita (M.Ped, M.Phil., Ph.D. (Phy.Edu.), M.A. (Eng.) PGDCA, B.Ed,), Ms. Neeru Mehta (M.A (Pol.Sci), B.Ed), Ms. Vandana Jain (M.A (Eng, Edu), M.Phil (Eng), M.Ed, HNC (Computers, STET & HTET (PGT), Dr. Nirmala Devi (M.Ped, M.Phil, Ph.D. (Phy.Edu.), NIS), Ms. Birpal Kaur (M.A, M.Phil. (Eco), B.Ed.), Ms. Anju Sharma (M.A Hon’s (Pbi), B.Ed, Gyani, OT, B.A, B.Ed, M.Phil (Pbi), HTET (TGT & PGT), Ms. Neena Mehta (M.A (Hindi), B.Ed, M.Lib, M.Phil (Lib. Sc.), Ms. Seema Palta (M.A (Eng, Edu), M.Phil (Eng), B.Ed), Ms. Veena (M.A (Hindi, Music), Prabhakar).
            </p>
            </div>
           
        </div>
    </div>
</section>

<?php include('inc_footer.php');?>

<!-- start scroll top -->
<div id="scroll-top">
    <i class="la la-arrow-up" title="Go top"></i>
</div>
<!-- end scroll top -->

<!-- template js files -->
<?php include('footer.php');?>
</body>

<!-- Mirrored from techydevs.com/demos/themes/html/aduca-demo/aduca/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Jun 2022 06:17:33 GMT -->
</html>