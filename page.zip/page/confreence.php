<!DOCTYPE html>
<html lang="en">
  <!-- Mirrored from techydevs.com/demos/themes/html/aduca-demo/aduca/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Jun 2022 06:17:33 GMT -->
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="TechyDevs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Shah Satnam ji Girls School Sirsa | Confreence  </title>
    <!-- Google fonts --> <?php include('inc_include.php');?>
    <!-- end inject -->
  </head>
  <style>
    .heading_text {
      text-align: center;
    }
  </style>
  <body> <?php 
$menu="conferences.php";
include('header.php');?>
    <!-- ================================
    START BREADCRUMB AREA
================================= -->
    <section class="breadcrumb-area section-padding img-bg-2">
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="breadcrumb-content d-flex flex-wrap align-items-center justify-content-between">
              <div class="section-heading">
                <h2 class="section__title text-white">Conferences and Seminars</h2>
              </div>
              <ul class="generic-list-item generic-list-item-white generic-list-item-arrow d-flex flex-wrap align-items-center">
                <li>
                  <a href="index.php">Home</a>
                </li>
                <li>
                <a href="academic.php">Academics</a>
                </li>
                <li>Conferences and Seminars</li>
              </ul>
            </div>
            <!-- end breadcrumb-content -->
          </div>
          <!-- end col-lg-12 -->
        </div>
        <!-- end row -->
      </div>
      <!-- end container -->
    </section>
    <!-- end breadcrumb-area -->
    <!-- ================================
    END BREADCRUMB AREA
================================= -->
    <!-- ==================================
START ABOUT AREA
================================= -->
    <section>
      <div class="container mt-5">
      <div class="section-heading text-center">
            <h2 class="section__title">Conferences and Seminars</h2>
            <span class="section-divider"></span>
          </div>
        <div class="col-lg-12">
          <p class="common-text">
        
          Seminars and Workshops support the passionate interaction and active participation for boosting the skills and knowledge of students. It is a prime concern of the institute to develop the innovative skill of the students at an early age. Seminars and workshops are an innovative and welcomed step towards modern education. Generally organized for either a single day or couple of days, the objective of seminars and workshops is to assemble the compatible intellectuals and professionals to trade ideas, thoughts, and views related to a specific topic. 
 Far from the textbooks and academic syllabus, students research and learn on their own in a different learning environment from classrooms where they learn more effectively and efficiently. 

         <br>
        <div class="col-lg-12">
        <br>
        1.	Conference on Implementation Aspects of New Education Policy On 10th August 2022.<br>
2.	Seminar on Sharing & Enriching Learning experiences By Dr. Sheela Puniya on 14th October, 2019. <br>
3.	Etiquette Workshop by Dr. Mansi Gupta (Soft Skil & Grooming Expert, Bangalore) on May 2018. <br>
4.	Career Counselling cum Motivational Seminar by Mr. Amit Kumar (Assist. Manager, Chandigarh University), Ms. Sunita Gujjar (Mount Everest Conqueror) & Ms.
 Anita Kundu (First Indian Women to Climb Mount Everest) on February 2018.<br>
5.	Workshop on Positive Attitude & Communication Skills, Resource Person: Rashmi Chari Oxford University Press on 04th October, 2018. <br>
<br><br>
<h4>Workshop for Teachers</h4>
1.	Project Based Learning (Resource Person: Mr. Jim Moulton (USA) on 7th September, 2019.<br>
2.	Capacity Building Programme & Remodeled Assessment (Resource Person: Mr. Vivek Tiwari Principal D.A.V. School) on 24th August, 2019.<br>
3.	Workshop on Mathematics (Resource Person: Mr. S. N. Chibbar Secretary of Delhi Association of Mathematics) on 7th May, 2019.<br>

        </div>
        <div class="col-lg-12 mt-5 mb-5">
           <div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class=""></li>
    <li data-target="#myCarousel" data-slide-to="1" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
    <li data-target="#myCarousel" data-slide-to="3"></li>
    <li data-target="#myCarousel" data-slide-to="4"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
   

    <div class="item active">
      <img src="images/academics/confreence/2.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>

    <div class="item">
      <img src="images/academics/confreence/3.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>
    <div class="item">
      <img src="images/academics/confreence/4.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>
    <div class="item">
      <img src="images/academics/confreence/5.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>
    <div class="item">
      <img src="images/academics/confreence/6.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>

    <div class="item">
      <img src="images/academics/confreence/7.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>

    <div class="item">
      <img src="images/academics/confreence/8.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>
    <div class="item">
      <img src="images/academics/confreence/9.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>
    <div class="item">
      <img src="images/academics/confreence/10.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>
    <div class="item">
      <img src="images/academics/confreence/11.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>

    <div class="item">
      <img src="images/academics/confreence/12.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>

    <div class="item">
      <img src="images/academics/confreence/13.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>
    <div class="item">
      <img src="images/academics/confreence/14.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>
    <div class="item">
      <img src="images/academics/confreence/15.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>
    <div class="item">
      <img src="images/academics/confreence/16.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>

    <div class="item">
      <img src="images/academics/confreence/17.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>
    <div class="item">
      <img src="images/academics/confreence/18.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>
    <div class="item">
      <img src="images/academics/confreence/19.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>

    <div class="item">
      <img src="images/academics/confreence/20.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>

    <div class="item">
      <img src="images/academics/confreence/21.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>
    <div class="item">
      <img src="images/academics/confreence/22.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>
    <div class="item">
      <img src="images/academics/confreence/23.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>
    <div class="item">
      <img src="images/academics/confreence/24.PNG" alt="Shah Satanam" title="shah satnam scr. girls school">
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
            
            </div></div>

        </div>
      </div>
    </section>
    <section>
     
  
    <!-- ==================================
END ABOUT AREA
================================= --> <?php include('inc_footer.php');?>
    <!-- start scroll top -->
    <div id="scroll-top">
      <i class="la la-arrow-up" title="Go top"></i>
    </div>
    <!-- end scroll top -->
    <!-- template js files --> <?php include('footer.php');?>
  </body>
  <!-- Mirrored from techydevs.com/demos/themes/html/aduca-demo/aduca/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Jun 2022 06:17:33 GMT -->
</html>